package data;

/**
 * Created by David on 1/15/2017.
 */
//public enum State {
//    MINE,
//    BANK,
//    WALK_TO_BANK,
//    WALK_TO_MINE,
//
//}
